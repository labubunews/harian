DROP TABLE IF EXISTS `#__allvideoshare_categories`;
DROP TABLE IF EXISTS `#__allvideoshare_videos`;
DROP TABLE IF EXISTS `#__allvideoshare_adverts`;
DROP TABLE IF EXISTS `#__allvideoshare_players`;
DROP TABLE IF EXISTS `#__allvideoshare_ratings`;
DROP TABLE IF EXISTS `#__allvideoshare_likes`;
DROP TABLE IF EXISTS `#__allvideoshare_options`;
DROP TABLE IF EXISTS `#__allvideoshare_cache`;