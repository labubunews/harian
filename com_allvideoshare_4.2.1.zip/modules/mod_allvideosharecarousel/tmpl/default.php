<?php
/**
 * @version     4.2.0
 * @package     Com_AllVideoShare
 * @subpackage  Mod_AllVideoShareGallery
 * @author      Vinoth Kumar <admin@mrvinoth.com>
 * @copyright   Copyright (c) 2012 - 2023 Vinoth Kumar. All Rights Reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined( '_JEXEC' ) or die;

use Joomla\CMS\Date\Date;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use MrVinoth\Component\AllVideoShare\Site\Helper\AllVideoShareHelper;
use MrVinoth\Component\AllVideoShare\Site\Helper\AllVideoSharePlayer;
use MrVinoth\Component\AllVideoShare\Site\Helper\AllVideoShareRoute;
use MrVinoth\Module\AllVideoShareCarousel\Site\Helper\AllVideoShareCarouselHelper;

$language = Factory::getLanguage();

// Vars
$params_array = array_keys( $params->toArray() );
$player_args  = array();

foreach ( $params_array as $option ) {
    $value = $params->get( $option, '' );
    if ( $value != '' ) {
        $player_args[ $option ] = $value;
    }
}

$params = AllVideoShareHelper::resolveParams( $params );
$items  = AllVideoShareCarouselHelper::getItems( $params );

$player_ratio = $params->get( 'player_ratio', 56.25 );
$image_ratio  = $params->get( 'image_ratio', 56.25 );
$popup_class  = AllVideoShareHelper::getCSSClassNames( $params, 'slick.popup' );

$custom_route = $params->get( 'link' );
if ( ! empty( $custom_route ) ) {
	$custom_route  = str_replace( 'slg=', '', $custom_route );
	$custom_route .= ! strpos( $custom_route, '?' ) ? '?slg=' : '&slg=';
}

$attributes = array();
$attributes['uid'] = $module->id;
$attributes['slider_layout'] = $params->get( 'slider_layout', 'both' );
$attributes['columns'] = $params->get( 'columns', 3 );

$data_params = array(
    'is_rtl'             => $language->get( 'rtl' ),
    'arrow_size'         => (int) $params->get( 'arrow_size', 24 ) . 'px',
    'arrow_bg_color'     => $params->get( 'arrow_bg_color', '#08c' ),
    'arrow_icon_size'    => (int) $params->get( 'arrow_size', 24 ) - 5 . 'px',
    'arrow_icon_color'   => $params->get( 'arrow_icon_color', '#fff' ),		
    'arrow_radius'       => (int) $params->get( 'arrow_radius', 12 ) . 'px',
    'arrow_top_offset'   => (int) $params->get( 'arrow_top_offset', 50 ) . '%',
    'arrow_left_offset'  => (int) $params->get( 'arrow_left_offset', -25 ) . 'px',
    'arrow_right_offset' => (int) $params->get( 'arrow_right_offset', -25 ) . 'px',
    'dot_size'           => (int) $params->get( 'dot_size', 24 ) . 'px',
    'dot_color'          => $params->get( 'dot_color', '#08c' )
);

$slick = array(
    'videos'     => array(
        'arrows' => ! empty( $params->get( 'arrows', 0 ) ) ? true : false,
        'dots'   => ! empty( $params->get( 'dots', 0 ) ) ? true : false
    ),
    'thumbnails' => array(
        'slidesToShow'   => (int) $attributes['columns'],
	    'slidesToScroll' => 1,
        'arrows'         => ! empty( $params->get( 'arrows', 0 ) ) ? true : false,
        'dots'           => ! empty( $params->get( 'dots', 0 ) ) ? true : false,
        'responsive'     => array()
    )
);

if ( (int) $attributes['columns'] > 3 ) {
    $slick['thumbnails']['responsive'][] = array(
        'breakpoint' => 768,
        'settings'   => array(
            'slidesToShow' => 3
        )
    );
}

if ( (int) $attributes['columns'] > 2 ) {
    $slick['thumbnails']['responsive'][] = array(
        'breakpoint' => 640,
        'settings'   => array(
            'slidesToShow' => 2
        )
    );
}

if ( 'both' == $attributes['slider_layout'] ) {	
    $slick['videos'] = array(
        'arrows' => false,
        'dots'   => false,
        'fade'   => true
    );

    if ( ! $params->get( 'popup' ) ) {
        $slick['videos']['asNavFor'] = '#avs-slider-thumbnails-' . $attributes['uid'];

        $slick['thumbnails']['asNavFor'] = '#avs-slider-player-' . $attributes['uid'];
        $slick['thumbnails']['focusOnSelect'] = true;
    }    
}

// Import CSS & JS
$wa = $app->getDocument()->getWebAssetManager();

if ( ! $wa->assetExists( 'style', 'com_allvideoshare.site' ) ) {
	$wr = $wa->getRegistry();
	$wr->addRegistryFile( 'media/com_allvideoshare/joomla.asset.json' );
}

if ( $params->get( 'load_bootstrap' ) ) {
	$wa->useStyle( 'com_allvideoshare.bootstrap' );
}

if ( $params->get( 'popup' ) ) {
	$wa->useStyle( 'com_allvideoshare.popup' )
		->useScript( 'com_allvideoshare.popup' );
}

$wa->useStyle( 'com_allvideoshare.slider' )
    ->useStyle( 'com_allvideoshare.site' )
    ->useScript( 'com_allvideoshare.slider' )
    ->useScript( 'com_allvideoshare.site' );

if ( $css = $params->get( 'custom_css' ) ) {
    $wa->addInlineStyle( $css );
}
?>

<div class="avs avs-slider avs-slider-layout-<?php echo $attributes['slider_layout']; ?> mod_allvideosharecarousel">
    <?php if ( empty( $items ) ) : ?>
		<p class="text-muted">
			<?php echo Text::_( 'MOD_ALLVIDEOSHARECAROUSEL_NO_VIDEOS_FOUND' ); ?>
		</p>
	<?php else : ?>
        <?php if ( 'player' == $attributes['slider_layout'] || 'both' == $attributes['slider_layout'] ) : ?>
            <!-- Videos -->
            <div id="avs-slider-player-<?php echo $attributes['uid']; ?>" class="avs-slider-player avs-slick" data-type="player" data-slick='<?php echo json_encode( $slick['videos'] ); ?>' data-params='<?php echo json_encode( $data_params ); ?>'>
                <?php
                // Start the loop            
                foreach ( $items as $i => $item ) : ?>            
                    <div class="avs-grid-item avs-video-<?php echo (int) $item->id; ?>">
                        <div class="avs-player-container">
                            <?php
                            $player_args['id'] = $item->id;    
                            if ( $i > 0 ) {
                                $player_args['autoplay'] = 1;
                            }

                            $iframe_src = AllVideoSharePlayer::getURL( $player_args );
                            ?>
                            <div class="avs-player" style="padding-bottom: <?php echo (float) $player_ratio; ?>%;" data-src="<?php echo $iframe_src; ?>">
                                <?php if ( 0 == $i ) : ?>
                                    <iframe src="<?php echo $iframe_src; ?>" frameborder="0" scrolling="no" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                                <?php endif; ?>
                            </div>
                        </div> 
                    </div>         
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ( 'thumbnails' == $attributes['slider_layout'] || 'both' == $attributes['slider_layout'] ) : ?>
            <!-- Thumbnails -->
            <div id="avs-slider-thumbnails-<?php echo $attributes['uid']; ?>" class="avs-slider-thumbnails avs-slick<?php echo $popup_class; ?>" data-type="thumbnails" data-slick='<?php echo json_encode( $slick['thumbnails'] ); ?>' data-params='<?php echo json_encode( $data_params ); ?>' data-player_ratio="<?php echo $player_ratio; ?>">
                <?php
                // Start the loop            
                foreach ( $items as $item ) :
                    if ( ! empty( $custom_route ) ) {
                        $route = $custom_route . $item->slug;
                    } else {
                        $route = AllVideoShareRoute::getVideoRoute( $item );
                    }
                    
                    $item_link = Route::_( $route );

                    if ( $params->get( 'popup' ) ||  $attributes['slider_layout'] == 'both' ) {
                        $item_link = 'javascript:void(0)';
                    }			

                    $player_args['id'] = $item->id;    
                    $player_args['autoplay'] = 1;

                    $iframe_src = AllVideoSharePlayer::getURL( $player_args );
                    ?>            
                    <div class="avs-grid-item avs-video-<?php echo (int) $item->id; ?>" data-mfp-src="<?php echo $iframe_src; ?>">
                        <div class="avs-card mb-3 p-2">
                            <a href="<?php echo $item_link; ?>" class="avs-responsive-item" style="padding-bottom: <?php echo (float) $image_ratio; ?>%">
                                <div class="avs-image" style="background-image: url( '<?php echo AllVideoShareHelper::getImage( $item ); ?>' );">&nbsp;</div>
                                
                                <svg class="avs-svg-icon avs-svg-icon-play" width="32" height="32" viewBox="0 0 32 32">
                                    <path d="M16 0c-8.837 0-16 7.163-16 16s7.163 16 16 16 16-7.163 16-16-7.163-16-16-16zM16 29c-7.18 0-13-5.82-13-13s5.82-13 13-13 13 5.82 13 13-5.82 13-13 13zM12 9l12 7-12 7z"></path>
                                </svg>
                            </a>

                            <div class="avs-card-body mt-2">
                                <div class="avs-title">
                                    <a href="<?php echo $item_link; ?>" class="card-link">
                                        <?php echo AllVideoShareHelper::Truncate( $item->title, $params->get( 'title_length', 0 ) ); ?>
                                    </a>
                                </div>                                

                                <?php
                                $meta = array();
                                    
                                // Author Name
                                if ( $params->get( 'author_name' ) ) {
                                    $meta[] = sprintf(
                                        '<span class="avs-meta-author"><span class="icon-user icon-fw"></span> %s</span>',
                                        Factory::getUser( $item->created_by )->username
                                    );
                                }

                                // Date Added
                                if ( $params->get( 'date_added' ) ) {
                                    $jdate = new Date( $item->created_date );
                                    $prettyDate = $jdate->format( Text::_( 'DATE_FORMAT_LC3' ) );

                                    $meta[] = sprintf(
                                        '<span class="avs-meta-date"><span class="icon-calendar icon-fw"></span> %s</span>',
                                        $prettyDate
                                    );
                                }

                                // Views Count
                                if ( $params->get( 'views' ) ) {
                                    $meta[] = sprintf(
                                        '<span class="avs-meta-views"><span class="icon-eye icon-fw"></span> %s</span>',
                                        Text::sprintf( 'MOD_ALLVIDEOSHARECAROUSEL_N_VIEWS_COUNT', $item->views )
                                    );
                                }	
                                
                                if ( count( $meta ) ) {
                                    printf( 
                                        '<div class="avs-meta text-muted small mt-1">%s</div>',
                                        implode( ' / ', $meta )
                                    );
                                }
                                ?>	

                                <?php 
                                // Categories
                                if ( $params->get( 'category_name' ) ) {
                                    $categories = array();

                                    if ( isset( $item->category ) && ! empty( $item->category ) ) {
                                        $route = AllVideoShareRoute::getCategoryRoute( $item->category );
                                        $item_link = Route::_( $route );

                                        $categories[] = sprintf(
                                            '<a href="%s">%s</a>',
                                            $item_link,
                                            $item->category->name
                                        ); 
                                    }

                                    if ( $params->get( 'multi_categories' ) && ! empty( $item->categories ) ) {
                                        foreach ( $item->categories as $category ) {
                                            $route = AllVideoShareRoute::getCategoryRoute( $category );
                                            $item_link = Route::_( $route );
                        
                                            $categories[] = sprintf(
                                                '<a href="%s">%s</a>',
                                                $item_link,
                                                $category->name
                                            );
                                        }
                                    }

                                    if ( ! empty( $categories ) ) {
                                        printf(
                                            '<div class="avs-categories text-muted small mt-1"><span class="icon-folder-open icon-fw"></span> %s</div>',
                                            implode( ', ', $categories )
                                        );
                                    }
                                }
                                ?>

                                <?php 
                                // Ratings
                                if ( $params->get( 'ratings' ) ) : ?>
                                    <div class="avs-ratings-small mt-1">
                                        <span class="avs-ratings-stars">
                                            <span class="avs-ratings-current" style="width: <?php echo (float) $item->ratings; ?>%;"></span>
                                        </span>
                                    </div>
                                <?php endif; ?> 

                                <?php 
                                // Short Description
                                if ( $params->get( 'excerpt' ) && ! empty( $item->description ) ) : ?>
									<div class="avs-excerpt small mt-2">
										<?php echo AllVideoShareHelper::Truncate( $item->description, $params->get( 'excerpt_length' ) ); ?>
									</div>
								<?php endif; ?>
                            </div>					
                        </div>
                    </div>            
                <?php endforeach; ?>
            </div>
        <?php endif; ?>	
    <?php endif; ?>	
</div>
