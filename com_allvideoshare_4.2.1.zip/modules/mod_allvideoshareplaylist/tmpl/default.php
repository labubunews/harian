<?php
/**
 * @version     4.2.0
 * @package     Com_AllVideoShare
 * @subpackage  Mod_AllVideoSharePlaylist
 * @author      Vinoth Kumar <admin@mrvinoth.com>
 * @copyright   Copyright (c) 2012 - 2023 Vinoth Kumar. All Rights Reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined( '_JEXEC' ) or die;

use Joomla\CMS\Date\Date;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use MrVinoth\Component\AllVideoShare\Site\Helper\AllVideoShareHelper;
use MrVinoth\Component\AllVideoShare\Site\Helper\AllVideoSharePlayer;
use MrVinoth\Module\AllVideoSharePlaylist\Site\Helper\AllVideoSharePlaylistHelper;
use MrVinoth\Component\AllVideoShare\Site\Helper\AllVideoShareRoute;

// Vars
$uid = (int) $module->id;

$params_array = array_keys( $params->toArray() );
$player_args  = array(
    'uid' => $uid
);

foreach ( $params_array as $option ) {
    $value = $params->get( $option, '' );
    if ( $value != '' ) {
        $player_args[ $option ] = $value;
    }
}

$params = AllVideoShareHelper::resolveParams( $params );
$items  = AllVideoSharePlaylistHelper::getItems( $params );

$player_ratio = (float) $params->get( 'player_ratio', 56.25 );
$image_ratio = (float) $params->get( 'image_ratio', 56.25 );
$playlist_position = ( 'bottom' == $params->get( 'playlist_position', '' ) ? 'bottom' : 'right' );
$playlist_width = (int) $params->get( 'playlist_width', 250 );
$playlist_height = (int) $params->get( 'playlist_height', 250 );
$playlist_color = ( 'light' == $params->get( 'playlist_color', '' ) ? 'light' : 'dark' );

// Import CSS & JS
$wa = $app->getDocument()->getWebAssetManager();

if ( ! $wa->assetExists( 'style', 'com_allvideoshare.site' ) ) {
	$wr = $wa->getRegistry();
	$wr->addRegistryFile( 'media/com_allvideoshare/joomla.asset.json' );
}

if ( $params->get( 'load_bootstrap' ) ) {
	$wa->useStyle( 'com_allvideoshare.bootstrap' );
}

$wa->useStyle( 'com_allvideoshare.site' );

$inlineStyle = $params->get( 'custom_css' );

if ( $playlist_position == 'right' ) {
    $inlineStyle .= "
        #avs-playlist-" . $uid . " .avs-playlist-player {
            width: calc(100% - " . $playlist_width . "px);
        }

        #avs-playlist-" . $uid . " .avs-playlist-videos {
            width: " . $playlist_width . "px;
        }

        @media only screen and (max-width: 768px) {
            #avs-playlist-" . $uid . " .avs-playlist-player,
            #avs-playlist-" . $uid . " .avs-playlist-videos {
                width: 100%;
            }

            #avs-playlist-" . $uid . " .avs-playlist-videos {
                max-height: " . $playlist_height . "px;
                overflow-y: scroll;
            }
        }
    ";
} else {
    $inlineStyle .= "
        #avs-playlist-" . $uid . " .avs-playlist-videos {
            max-height: " . $playlist_height . "px;
            overflow-y: scroll;
        }
    ";
}

if ( ! empty( $inlineStyle ) ) {
    $wa->addInlineStyle( $inlineStyle );
}

$wa->useScript( 'com_allvideoshare.site' );
?>

<div id="avs-playlist-<?php echo $uid; ?>" class="avs playlist mod_allvideoshareplaylist">
    <?php if ( empty( $items ) ) : ?>
		<p class="text-muted">
			<?php echo Text::_( 'MOD_ALLVIDEOSHAREPLAYLIST_NO_VIDEOS_FOUND' ); ?>
		</p>
	<?php else : ?>
        <div class="avs-playlist <?php echo $playlist_position; ?> <?php echo $playlist_color; ?>">
            <!-- Player -->
            <div class="avs-playlist-player avs-playlist-container">
                <?php
                $player_args['id'] = $items[0]->id;    
                $iframe_src = AllVideoSharePlayer::getURL( $player_args );
                ?>
                <div class="avs-player" style="padding-bottom: <?php echo $player_ratio; ?>%;">
                    <iframe id="avs-player-<?php echo $uid; ?>" width="100%" height="100%" src="<?php echo $iframe_src; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>

            <!-- Playlist -->
            <div class="avs-playlist-videos">
                <div class="avs-videos">
                    <?php foreach ( $items as $index => $item ) :
                        $class_suffix = ( $index == 0 ) ? ' avs-active' : '';

                        $player_args['id'] = $item->id;    
                        $player_args['autoplay'] = 1;

                        $iframe_src = AllVideoSharePlayer::getURL( $player_args );
                        ?>
                        <div class="avs-video<?php echo $class_suffix; ?>" data-index="<?php echo $index; ?>" data-src="<?php echo $iframe_src; ?>">
                            <div class="d-flex p-2">
                                <div class="flex-shrink-0">
                                    <div class="avs-responsive-item" style="padding-bottom: <?php echo $image_ratio; ?>%">
                                        <div class="avs-image" style="background-image: url( '<?php echo AllVideoShareHelper::getImage( $item ); ?>' );">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <div class="avs-title">
                                        <?php echo AllVideoShareHelper::Truncate( $item->title, $params->get( 'title_length', 0 ) ); ?>
                                    </div>                                    

                                    <?php
                                    $meta = array();
                                        
                                    // Author Name
                                    if ( $params->get( 'author_name' ) ) {
                                        $meta[] = sprintf(
                                            '<span class="avs-meta-author"><span class="icon-user icon-fw"></span> %s</span>',
                                            Factory::getUser( $item->created_by )->username
                                        );
                                    }

                                    // Date Added
                                    if ( $params->get( 'date_added' ) ) {
                                        $jdate = new Date( $item->created_date );
                                        $prettyDate = $jdate->format( Text::_( 'DATE_FORMAT_LC3' ) );

                                        $meta[] = sprintf(
                                            '<span class="avs-meta-date"><span class="icon-calendar icon-fw"></span> %s</span>',
                                            $prettyDate
                                        );
                                    }

                                    // Views Count
                                    if ( $params->get( 'views' ) ) {
                                        $meta[] = sprintf(
                                            '<span class="avs-meta-views"><span class="icon-eye icon-fw"></span> %s</span>',
                                            Text::sprintf( 'MOD_ALLVIDEOSHAREPLAYLIST_N_VIEWS_COUNT', $item->views )
                                        );
                                    }	
                                    
                                    if ( count( $meta ) ) {
                                        printf( 
                                            '<div class="avs-meta text-muted small mt-1">%s</div>',
                                            implode( ' / ', $meta )
                                        );
                                    }
                                    ?>	

                                    <?php 
                                    // Categories
                                    if ( $params->get( 'category_name' ) ) {
                                        $categories = array();

                                        if ( isset( $item->category ) && ! empty( $item->category ) ) {
                                            $route = AllVideoShareRoute::getCategoryRoute( $item->category );
                                            $item_link = Route::_( $route );

                                            $categories[] = sprintf(
                                                '<a href="%s" class="text-muted">%s</a>',
                                                $item_link,
                                                $item->category->name
                                            ); 
                                        }

                                        if ( $params->get( 'multi_categories' ) && ! empty( $item->categories ) ) {
                                            foreach ( $item->categories as $category ) {
                                                $route = AllVideoShareRoute::getCategoryRoute( $category );
                                                $item_link = Route::_( $route );
                            
                                                $categories[] = sprintf(
                                                    '<a href="%s" class="text-muted">%s</a>',
                                                    $item_link,
                                                    $category->name
                                                );
                                            }
                                        }

                                        if ( ! empty( $categories ) ) {
                                            printf(
                                                '<div class="avs-categories text-muted small mt-1"><span class="icon-folder-open icon-fw"></span> %s</div>',
                                                implode( ', ', $categories )
                                            );
                                        }
                                    }
                                    ?>

                                    <?php 
                                    // Ratings
                                    if ( $params->get( 'ratings' ) ) : ?>
                                        <div class="avs-ratings-small mt-1">
                                            <span class="avs-ratings-stars">
                                                <span class="avs-ratings-current" style="width: <?php echo (float) $item->ratings; ?>%;"></span>
                                            </span>
                                        </div>
                                    <?php endif; ?> 

                                    <?php 
                                    // Short Description
                                    if ( $params->get( 'excerpt' ) && ! empty( $item->description ) ) : ?>
                                        <div class="avs-excerpt small text-muted mt-2"><?php echo AllVideoShareHelper::Truncate( $item->description, $params->get( 'excerpt_length' ) ); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>	
    <?php endif; ?>	
</div>
