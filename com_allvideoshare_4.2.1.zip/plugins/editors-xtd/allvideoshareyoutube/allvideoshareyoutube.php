<?php
/**
 * @version    4.2.0
 * @package    Com_AllVideoShare
 * @author     Vinoth Kumar <admin@mrvinoth.com>
 * @copyright  Copyright (c) 2012 - 2023 Vinoth Kumar. All Rights Reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined( '_JEXEC' ) or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Object\CMSObject;
use Joomla\CMS\Plugin\CMSPlugin;

/**
 * Editor YouTube Gallery button
 *
 * @since  4.1.2
 */
class PlgButtonAllVideoShareYouTube extends CMSPlugin {

	/**
	 * Load the language file on instantiation.
	 *
	 * @var    boolean
	 * @since  4.1.2
	 */
	protected $autoloadLanguage = true;

	/**
	 * Display the button
	 *
	 * @param   string  $name  The name of the button to add
	 *
	 * @return  CMSObject|void  The button options as CMSObject
	 *
	 * @since   4.1.2
	 */
	public function onDisplay( $name ) {
		$doc  = Factory::getDocument();
		$user = Factory::getUser();

		// Can create in any category (component permission) or at least in one category
		$canCreateRecords = $user->authorise( 'core.create', 'com_content' )
			|| count( $user->getAuthorisedCategories( 'com_content', 'core.create' ) ) > 0;

		// Instead of checking edit on all records, we can use **same** check as the form editing view
		$values = (array) Factory::getApplication()->getUserState( 'com_content.edit.article.id' );
		$isEditingRecords = count( $values );

		// This ACL check is probably a double-check (form view already performed checks)
		$hasAccess = $canCreateRecords || $isEditingRecords;
		if ( ! $hasAccess )	{
			return;
		}

		$wa = $doc->getWebAssetManager();

		if ( ! $wa->assetExists( 'script', 'com_allvideoshare.shortcode' ) ) {
			$wr = $wa->getRegistry();
			$wr->addRegistryFile( 'media/com_allvideoshare/joomla.asset.json' );
		}

		$wa->useScript( 'com_allvideoshare.shortcode' );

		$link = 'index.php?option=com_allvideoshare&amp;view=youtube&amp;tmpl=component&amp;e_name=' . $name;

		$button = new CMSObject;
		$button->modal   = true;
		$button->link    = $link;
		$button->text    = Text::_( 'PLG_EDITORS-XTD_ALLVIDEOSHAREYOUTUBE_BUTTON_LBL_YOUTUBE_GALLERY' );
		$button->name    = $this->_type . '_' . $this->_name;
		$button->icon    = 'youtube';
		$button->iconSVG = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-youtube" viewBox="0 0 16 16"><path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A99.788 99.788 0 0 1 7.858 2h.193zM6.4 5.209v4.818l4.157-2.408L6.4 5.209z"/></svg>';
		$button->options = [
			'height'          => '200px',
			'width'           => '400px',
			'bodyHeight'      => '70',
			'modalWidth'      => '80',
			'tinyPath'        => $link,
			'confirmCallback' => 'window.avsInsertYouTubeGallery(\'' . $name . '\')',
			'confirmText'     => Text::_( 'PLG_EDITORS-XTD_ALLVIDEOSHAREYOUTUBE_BUTTON_LBL_INSERT_GALLERY' )
		];

		return $button;
	}
}
