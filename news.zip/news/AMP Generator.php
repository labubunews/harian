<?php
function createAmpFile($slug, $metaTitle, $metaDescription, $canonicalUrl) {
    echo <<<HTML
    <!-- HTML MU DI SINI KAWAN SC BY MINGCIBAI -->


<!DOCTYPE html>
<html amp="" data-amp-auto-lightbox-disable transformed="self;v=1" i-amphtml-layout="" i-amphtml-no-boilerplate="">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,maximum-scale=1"><link rel="preconnect" href="https://cdn.ampproject.org"><style amp-runtime="" i-amphtml-version="012410161801000">html{overflow-x:hidden!important}html.i-amphtml-fie{height:100%!important;width:100%!important}html:not([amp4ads]),html:not([amp4ads]) body{height:auto!important}html:not([amp4ads]) body{margin:0!important}body{-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;-ms-text-size-adjust:100%;text-size-adjust:100%}html.i-amphtml-singledoc.i-amphtml-embedded{-ms-touch-action:pan-y pinch-zoom;touch-action:pan-y pinch-zoom}html.i-amphtml-fie>body,html.i-amphtml-singledoc>body{overflow:visible!important}html.i-amphtml-fie:not(.i-amphtml-inabox)>body,html.i-amphtml-singledoc:not(.i-amphtml-inabox)>body{position:relative!important}html.i-amphtml-ios-embed-legacy>body{overflow-x:hidden!important;overflow-y:auto!important;position:absolute!important}html.i-amphtml-ios-embed{overflow-y:auto!important;position:static}#i-amphtml-wrapper{overflow-x:hidden!important;overflow-y:auto!important;position:absolute!important;top:0!important;left:0!important;right:0!important;bottom:0!important;margin:0!important;display:block!important}html.i-amphtml-ios-embed.i-amphtml-ios-overscroll,html.i-amphtml-ios-embed.i-amphtml-ios-overscroll>#i-amphtml-wrapper{-webkit-overflow-scrolling:touch!important}#i-amphtml-wrapper>body{position:relative!important;border-top:1px solid transparent!important}#i-amphtml-wrapper+body{visibility:visible}#i-amphtml-wrapper+body .i-amphtml-lightbox-element,#i-amphtml-wrapper+body[i-amphtml-lightbox]{visibility:hidden}#i-amphtml-wrapper+body[i-amphtml-lightbox] .i-amphtml-lightbox-element{visibility:visible}#i-amphtml-wrapper.i-amphtml-scroll-disabled,.i-amphtml-scroll-disabled{overflow-x:hidden!important;overflow-y:hidden!important}amp-instagram{padding:54px 0px 0px!important;background-color:#fff}amp-iframe iframe{box-sizing:border-box!important}[amp-access][amp-access-hide]{display:none}[subscriptions-dialog],body:not(.i-amphtml-subs-ready) [subscriptions-action],body:not(.i-amphtml-subs-ready) [subscriptions-section]{display:none!important}amp-experiment,amp-live-list>[update]{display:none}amp-list[resizable-children]>.i-amphtml-loading-container.amp-hidden{display:none!important}amp-list [fetch-error],amp-list[load-more] [load-more-button],amp-list[load-more] [load-more-end],amp-list[load-more] [load-more-failed],amp-list[load-more] [load-more-loading]{display:none}amp-list[diffable] div[role=list]{display:block}amp-story-page,amp-story[standalone]{min-height:1px!important;display:block!important;height:100%!important;margin:0!important;padding:0!important;overflow:hidden!important;width:100%!important}amp-story[standalone]{background-color:#000!important;position:relative!important}amp-story-page{background-color:#757575}amp-story .amp-active>div,amp-story .i-amphtml-loader-background{display:none!important}amp-story-page:not(:first-of-type):not([distance]):not([active]){transform:translateY(1000vh)!important}amp-autocomplete{position:relative!important;display:inline-block!important}amp-autocomplete>input,amp-autocomplete>textarea{padding:0.5rem;border:1px solid rgba(0,0,0,.33)}.i-amphtml-autocomplete-results,amp-autocomplete>input,amp-autocomplete>textarea{font-size:1rem;line-height:1.5rem}[amp-fx^=fly-in]{visibility:hidden}amp-script[nodom],amp-script[sandboxed]{position:fixed!important;top:0!important;width:1px!important;height:1px!important;overflow:hidden!important;visibility:hidden}
/*# sourceURL=/css/ampdoc.css*/[hidden]{display:none!important}.i-amphtml-element{display:inline-block}.i-amphtml-blurry-placeholder{transition:opacity 0.3s cubic-bezier(0.0,0.0,0.2,1)!important;pointer-events:none}[layout=nodisplay]:not(.i-amphtml-element){display:none!important}.i-amphtml-layout-fixed,[layout=fixed][width][height]:not(.i-amphtml-layout-fixed){display:inline-block;position:relative}.i-amphtml-layout-responsive,[layout=responsive][width][height]:not(.i-amphtml-layout-responsive),[width][height][heights]:not([layout]):not(.i-amphtml-layout-responsive),[width][height][sizes]:not(img):not([layout]):not(.i-amphtml-layout-responsive){display:block;position:relative}.i-amphtml-layout-intrinsic,[layout=intrinsic][width][height]:not(.i-amphtml-layout-intrinsic){display:inline-block;position:relative;max-width:100%}.i-amphtml-layout-intrinsic .i-amphtml-sizer{max-width:100%}.i-amphtml-intrinsic-sizer{max-width:100%;display:block!important}.i-amphtml-layout-container,.i-amphtml-layout-fixed-height,[layout=container],[layout=fixed-height][height]:not(.i-amphtml-layout-fixed-height){display:block;position:relative}.i-amphtml-layout-fill,.i-amphtml-layout-fill.i-amphtml-notbuilt,[layout=fill]:not(.i-amphtml-layout-fill),body noscript>*{display:block;overflow:hidden!important;position:absolute;top:0;left:0;bottom:0;right:0}body noscript>*{position:absolute!important;width:100%;height:100%;z-index:2}body noscript{display:inline!important}.i-amphtml-layout-flex-item,[layout=flex-item]:not(.i-amphtml-layout-flex-item){display:block;position:relative;-ms-flex:1 1 auto;flex:1 1 auto}.i-amphtml-layout-fluid{position:relative}.i-amphtml-layout-size-defined{overflow:hidden!important}.i-amphtml-layout-awaiting-size{position:absolute!important;top:auto!important;bottom:auto!important}i-amphtml-sizer{display:block!important}@supports (aspect-ratio:1/1){i-amphtml-sizer.i-amphtml-disable-ar{display:none!important}}.i-amphtml-blurry-placeholder,.i-amphtml-fill-content{display:block;height:0;max-height:100%;max-width:100%;min-height:100%;min-width:100%;width:0;margin:auto}.i-amphtml-layout-size-defined .i-amphtml-fill-content{position:absolute;top:0;left:0;bottom:0;right:0}.i-amphtml-replaced-content,.i-amphtml-screen-reader{padding:0!important;border:none!important}.i-amphtml-screen-reader{position:fixed!important;top:0px!important;left:0px!important;width:4px!important;height:4px!important;opacity:0!important;overflow:hidden!important;margin:0!important;display:block!important;visibility:visible!important}.i-amphtml-screen-reader~.i-amphtml-screen-reader{left:8px!important}.i-amphtml-screen-reader~.i-amphtml-screen-reader~.i-amphtml-screen-reader{left:12px!important}.i-amphtml-screen-reader~.i-amphtml-screen-reader~.i-amphtml-screen-reader~.i-amphtml-screen-reader{left:16px!important}.i-amphtml-unresolved{position:relative;overflow:hidden!important}.i-amphtml-select-disabled{-webkit-user-select:none!important;-ms-user-select:none!important;user-select:none!important}.i-amphtml-notbuilt,[layout]:not(.i-amphtml-element),[width][height][heights]:not([layout]):not(.i-amphtml-element),[width][height][sizes]:not(img):not([layout]):not(.i-amphtml-element){position:relative;overflow:hidden!important;color:transparent!important}.i-amphtml-notbuilt:not(.i-amphtml-layout-container)>*,[layout]:not([layout=container]):not(.i-amphtml-element)>*,[width][height][heights]:not([layout]):not(.i-amphtml-element)>*,[width][height][sizes]:not([layout]):not(.i-amphtml-element)>*{display:none}amp-img:not(.i-amphtml-element)[i-amphtml-ssr]>img.i-amphtml-fill-content{display:block}.i-amphtml-notbuilt:not(.i-amphtml-layout-container),[layout]:not([layout=container]):not(.i-amphtml-element),[width][height][heights]:not([layout]):not(.i-amphtml-element),[width][height][sizes]:not(img):not([layout]):not(.i-amphtml-element){color:transparent!important;line-height:0!important}.i-amphtml-ghost{visibility:hidden!important}.i-amphtml-element>[placeholder],[layout]:not(.i-amphtml-element)>[placeholder],[width][height][heights]:not([layout]):not(.i-amphtml-element)>[placeholder],[width][height][sizes]:not([layout]):not(.i-amphtml-element)>[placeholder]{display:block;line-height:normal}.i-amphtml-element>[placeholder].amp-hidden,.i-amphtml-element>[placeholder].hidden{visibility:hidden}.i-amphtml-element:not(.amp-notsupported)>[fallback],.i-amphtml-layout-container>[placeholder].amp-hidden,.i-amphtml-layout-container>[placeholder].hidden{display:none}.i-amphtml-layout-size-defined>[fallback],.i-amphtml-layout-size-defined>[placeholder]{position:absolute!important;top:0!important;left:0!important;right:0!important;bottom:0!important;z-index:1}amp-img[i-amphtml-ssr]:not(.i-amphtml-element)>[placeholder]{z-index:auto}.i-amphtml-notbuilt>[placeholder]{display:block!important}.i-amphtml-hidden-by-media-query{display:none!important}.i-amphtml-element-error{background:red!important;color:#fff!important;position:relative!important}.i-amphtml-element-error:before{content:attr(error-message)}i-amp-scroll-container,i-amphtml-scroll-container{position:absolute;top:0;left:0;right:0;bottom:0;display:block}i-amp-scroll-container.amp-active,i-amphtml-scroll-container.amp-active{overflow:auto;-webkit-overflow-scrolling:touch}.i-amphtml-loading-container{display:block!important;pointer-events:none;z-index:1}.i-amphtml-notbuilt>.i-amphtml-loading-container{display:block!important}.i-amphtml-loading-container.amp-hidden{visibility:hidden}.i-amphtml-element>[overflow]{cursor:pointer;position:relative;z-index:2;visibility:hidden;display:initial;line-height:normal}.i-amphtml-layout-size-defined>[overflow]{position:absolute}.i-amphtml-element>[overflow].amp-visible{visibility:visible}template{display:none!important}.amp-border-box,.amp-border-box *,.amp-border-box :after,.amp-border-box :before{box-sizing:border-box}amp-pixel{display:none!important}amp-analytics,amp-auto-ads,amp-story-auto-ads{position:fixed!important;top:0!important;width:1px!important;height:1px!important;overflow:hidden!important;visibility:hidden}amp-story{visibility:hidden!important}html.i-amphtml-fie>amp-analytics{position:initial!important}[visible-when-invalid]:not(.visible),form [submit-error],form [submit-success],form [submitting]{display:none}amp-accordion{display:block!important}@media (min-width:1px){:where(amp-accordion>section)>:first-child{margin:0;background-color:#efefef;padding-right:20px;border:1px solid #dfdfdf}:where(amp-accordion>section)>:last-child{margin:0}}amp-accordion>section{float:none!important}amp-accordion>section>*{float:none!important;display:block!important;overflow:hidden!important;position:relative!important}amp-accordion,amp-accordion>section{margin:0}amp-accordion:not(.i-amphtml-built)>section>:last-child{display:none!important}amp-accordion:not(.i-amphtml-built)>section[expanded]>:last-child{display:block!important}
/*# sourceURL=/css/ampshared.css*/</style><meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"><meta name="description" content="$metaDescription"><meta property="og:locale" content="id_ID"><meta property="og:type" content="website"><meta property="og:title" content="$metaTitle"><meta property="og:description" content="$metaDescription"><meta property="og:url" content="$canonicalUrl"><meta property="og:site_name" content="onixslot"><meta property="article:modified_time" content="2024-04-13T05:15:44+00:00"><meta name="twitter:card" content="summary_large_image"><meta name="generator" content="WordPress 6.6.2"><meta name="generator" content="AMP Plugin v2.5.4; mode=standard"><link rel="preload" href="https://onixslot.org/wp-content/themes/faeyza/webfonts/digital_sans_ef_medium.woff2" as="font" crossorigin=""><link rel="preload" href="https://onixslot.org/wp-content/themes/faeyza/webfonts/advanced_dot_digital7.eot" as="font" crossorigin=""><link rel="preload" href="https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-brands-400.eot#iefix" as="font" crossorigin=""><link rel="preload" href="https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-regular-400.eot#iefix" as="font" crossorigin=""><link rel="preload" href="https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-solid-900.eot#iefix" as="font" crossorigin=""><link rel="preload" href="https://onixslot.org/wp-content/themes/faeyza/webfonts/Lato-Regular.woff2" as="font" crossorigin=""><script async="" src="https://cdn.ampproject.org/v0.mjs" type="module" crossorigin="anonymous"></script><script async nomodule src="https://cdn.ampproject.org/v0.js" crossorigin="anonymous"></script><link rel="icon" type="image/png" href="https://onixslot.org/wp-content/themes/faeyza/images/favicon.png"><style amp-custom="">@media screen{html{height:100%;font-size:1em;font-size:100%;line-height:1.4;margin:0;padding:0;border:0;vertical-align:baseline}body{margin:0;font-size:14px;line-height:1.5;letter-spacing:.1px;color:#929292;background:#fefefe;font-family:"digital_sans_ef_medium"}h1{color:#fb00df;line-height:1.2;margin:15px 0px;font-weight:500;text-align:center}h1{font-size:30px}*{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}a,.main-menu li a{color:#f203d7;text-decoration:none}a:hover{color:#fff}div,input,label{display:block;overflow:hidden;position:relative}img{width:100%;height:auto;pointer-events:none;display:block}a img{pointer-events:visible}.mobile{display:none}@font-face{font-family:"digital_sans_ef_medium";src:url("https://onixslot.org/wp-content/themes/faeyza/webfonts/digital_sans_ef_medium.woff2") format("woff2"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/digital_sans_ef_medium.woff") format("woff");font-weight:normal;font-style:normal}@font-face{font-family:"advanced_dot_digital7";src:url("https://onixslot.org/wp-content/themes/faeyza/webfonts/advanced_dot_digital7.eot");src:url("https://onixslot.org/wp-content/themes/faeyza/webfonts/advanced_dot_digital7.eot") format("embedded-opentype"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/advanced_dot_digital7.woff2") format("woff2"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/advanced_dot_digital7.woff") format("woff"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/advanced_dot_digital7.ttf") format("truetype"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/advanced_dot_digital7.svg#advanced_dot_digital7") format("svg")}@font-face{font-family:"Font Awesome 5 Brands";font-style:normal;font-weight:normal;font-display:auto;src:url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-brands-400.eot");src:url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-brands-400.eot#iefix") format("embedded-opentype"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-brands-400.woff2") format("woff2"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-brands-400.woff") format("woff"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-brands-400.ttf") format("truetype"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-brands-400.svg#fontawesome") format("svg")}@font-face{font-family:"Font Awesome 5 Free";font-style:normal;font-weight:400;font-display:auto;src:url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-regular-400.eot");src:url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-regular-400.eot#iefix") format("embedded-opentype"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-regular-400.woff2") format("woff2"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-regular-400.woff") format("woff"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-regular-400.ttf") format("truetype"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-regular-400.svg#fontawesome") format("svg")}@font-face{font-family:"Font Awesome 5 Free";font-style:normal;font-weight:900;font-display:auto;src:url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-solid-900.eot");src:url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-solid-900.eot#iefix") format("embedded-opentype"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-solid-900.woff2") format("woff2"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-solid-900.woff") format("woff"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-solid-900.ttf") format("truetype"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/fa-solid-900.svg#fontawesome") format("svg")}@font-face{font-family:"LatoWeb";src:url("https://onixslot.org/wp-content/themes/faeyza/webfonts/Lato-Regular.woff2") format("woff2"),url("https://onixslot.org/wp-content/themes/faeyza/webfonts/Lato-Regular.woff") format("woff");font-weight:normal;font-style:normal}.svg-menu{height:20px;width:20px;display:inline-block;background-size:18px;background-repeat:no-repeat}.svg-beranda{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-beranda.svg")}.svg-content{display:inline-block;width:27px;height:22px;background-size:21px;background-repeat:no-repeat}.svg-casino{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-casino.svg")}.svg-slots{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-slots.svg")}.svg-togel{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-togel.svg")}.svg-poker{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-poker.svg")}.svg-fishing{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-fishing.svg")}.svg-gift{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-gift.svg")}.svg-link{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-link.svg")}.svg-jackpot{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-jackpot.svg")}.svg-livecasino{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-livecasino.svg")}.svg-esports{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-esports.svg")}.svg-sportsbook{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-sportsbook.svg")}.svg-whatsapp{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-whatsapp.svg")}.svg-telegram{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-telegram.svg")}.svg-livechat{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/icon/icon-livechat.svg")}.header{width:100%;z-index:999999;position:fixed;background:#131313}.top-left{float:left;width:27%;display:flex;justify-content:flex-start}.top-right{line-height:1.2;font-size:11px;float:right;width:70%}.site-logo{float:left;left:0px;width:24%;background:url("https://onixslot.org/wp-content/themes/faeyza/images/bg-header.png") center 0px;background-size:cover;background-repeat:no-repeat;height:89px}.site-logo a{display:block}.site-logo img{width:100%;height:auto;position:relative;top:18px}.nav-bar{border-top:1px solid #222}.nav-bar,.contact-floating{background:#000}.sticky{height:138px}.main{background:#191919}.slide{margin-bottom:17px}.sportsbook .slide{margin-bottom:0}.jackpot img{margin-left:auto;margin-right:auto;display:block;border-radius:12px}.container{max-width:1170px;width:100%;margin:auto;overflow:hidden}.row{width:100%;height:100%;display:flex;flex-wrap:wrap}.col-sm-2{flex:0 0 15.9%;max-width:15.9%;margin:5px 4px;justify-content:center;align-content:center}.col-sm-12{flex:0 0 100%;max-width:100%}.footer,.col-title{background:#111}.col-title{padding:9px 5px;position:absolute;top:-14px;left:21px;z-index:2}.col-border{border:1px solid #333;border-radius:7px;margin:5px auto;padding:18px}.payment .col-sm-12{margin:10px auto}.main-menu i{display:block;margin:auto;width:30px;height:30px;background-size:26px}ul.menu,ul.contact-us,ul.main-menu{padding:0;margin:0;text-transform:uppercase}.main-menu{float:right}.main-menu li a:hover,a:hover{color:#00ee94}.main-menu li{position:relative;display:block;float:left;margin:0;padding:0}.main-menu li a{font-size:13px;position:relative;display:inline-block;line-height:18px;padding:20px 25px;color:#f203d7}ul.contact-us{padding:15px 0;text-transform:capitalize}.contact-us{float:right;height:36px}.contact-us li{padding-right:10px;float:left;border-right:1px dotted #141414;padding-left:10px}.contact-us li:first-child{padding-left:0px}.contact-us li:last-child{border-right:0}.contact-us li a{font-size:12px;color:#828282}.contact-us li a:hover{color:#b6b6b6}.contact-us .svg-menu{height:20px;width:20px;display:inline-block;background-size:17px;background-repeat:no-repeat}.contact-us li i{vertical-align:middle}.quick-footer{position:fixed;width:170px;height:40px;bottom:0px;right:10px;background:#e8911a;border-radius:5px 5px 0px 0px;z-index:100;padding:2px}.quick-footer i{font-size:22px;position:relative;right:-38px;top:-2px}.quick-footer li{margin:1px auto;padding:4px 12px}.quick-footer li a{color:#fff;display:flex;align-items:end;text-align:center;font-size:19px;text-transform:uppercase}.quick-footer li i{vertical-align:middle}.quick-footer .svg-menu{height:25px;width:30px;display:inline-block;background-size:25px;background-repeat:no-repeat}.menu{float:right;position:relative;padding:0px;margin:0px auto}.menu li{float:left;position:relative;font-size:14px;text-transform:uppercase;min-width:68px;margin:0px 0px 0px 4px;text-align:center;padding:5px 5px;vertical-align:inherit;border-radius:27px}.menu ul{padding-top:15px;border-radius:0px 0px 4px 4px;-webkit-border-radius:0px 0px 4px 4px;-moz-border-radius:0px 0px 4px 4px;-ms-border-radius:0px 0px 4px 4px;-o-border-radius:0px 0px 4px 4px}.menu li a{padding:4px 21px;display:block;color:#fff;text-shadow:0px 0px 3px #454545}.daftar,.quick-footer{background:#d606c9;background-image:linear-gradient(to bottom,#6b2263,#ff00e3);border-top:1px solid #ff06c0}.daftar:hover{background:#ff0008;background-image:-webkit-linear-gradient(top,#ff06c0 0%,#ff29c9 100%)}.login{background:#00a871;background-image:linear-gradient(to bottom,#005732,#00fd9e);border-top:1px solid #00fdb6}.login:hover{background:#00490c;background-image:-webkit-linear-gradient(top,#00c08a 0%,#00fdb6 100%)}.login-panel{margin:6px 0}ul{list-style:none;margin:0;padding:5px 0px}ul.article{list-style:circle;padding:5px 30px}.article li{list-style:disc;margin:0px 0px 10px 35px}.ct-rounded,.ct-rounded img,.ct-rounded .col-sm-2,.bg-rounded .container{border-radius:12px}.bg-rounded .container{padding:25px;background:#020206;margin-bottom:30px}.ct-rounded{padding:15px;background:#282828;margin:10px auto;box-shadow:0px 0px 22px #000 inset}.ct-rounded .col-sm-2{padding:7px;background:#6b0060;background-image:linear-gradient(to bottom,#fb00df,#42003a);box-shadow:0px 0px 7px #181818}.ct-rounded,.jackpot img{border:3px solid #7e0070}.livecasino .image-wrapper,.sportsbook .image-wrapper,.slotgames .image-wrapper{background:#000;border-radius:12px;background-image:linear-gradient(to bottom,#2c2c2c,#000);box-shadow:0px 0px 6px #000 inset;border-bottom:2px solid #fb00df}.title-row{margin:21px auto;border-bottom:3px solid #aa0097;font-size:19px;display:flex;align-items:center;color:#f602db}.title-games{font-size:14px;padding:7px;color:#fff;text-overflow:ellipsis;white-space:nowrap;text-align:center;text-shadow:0 0 3px #534e23}.footer{width:100%;padding:0px 0px 20px 0px}.disclaimer{background:#000;border-top:1px solid #101013}.footer img{height:auto}.footer-title{font-size:15px;color:#d5d5d5;margin:20px auto}.footer .row{justify-content:left}.footer .col-sm-2{justify-content:center}.payment .col-sm-2{margin:4px;flex:0 0 11.7%;max-width:11.7%}.payment .col-sm-2{border-left:5px solid #59db00;padding:7px;background:#1a1a1a;text-align:center;border-radius:3px;color:#929292}.provider .col-sm-2{max-width:140px;margin:0px;flex:unset}.provider img{height:auto;width:80%}.copyright{font-size:11px;padding:15px 0px;text-align:center}.copyright a{color:#929292;display:inline-block}.article{text-align:left;color:#929292}.header .bg-line{height:3px;background:#363636;background:linear-gradient(90deg,#141414 0%,#fb00df 50%,#141414 100%)}.bg-line{height:3px;background:#363636;background:linear-gradient(90deg,#000 0%,#fb00df 50%,#000 100%)}@media only screen and (max-width: 768px){.main-slide img{height:100%}.main-menu,.top-header{display:none}.mobile{display:block}.desktop{display:none}.header{z-index:999999;height:62px;position:fixed;background:#000;border-bottom:1px solid #272218}.nav-bar{border:0}.sticky{height:62px}.site-logo{left:0px;right:0;width:50%;float:none;margin:auto;position:absolute;background-size:contain}.site-logo img{width:100%;max-width:198px;margin-left:auto;margin-right:auto;top:11px}.top-header{top:0px;left:0px;margin:auto;width:100%}.menu-mobile,.slide{width:100%;margin:auto}.menu-mobile .menu li{background-image:-webkit-linear-gradient(top,#ababab 0%,#585858 100%)}.menu{float:none}.main-mobile{background:#131313}.main-mobile li{width:23.3%;border-radius:7px;margin-bottom:5px;display:inline-block}.main-mobile li a{padding:7px;font-size:13px;display:flex;align-items:center;flex-wrap:nowrap;flex-direction:column;color:#00cc8b}.main-mobile li .svg-menu{height:30px;width:25px;background-size:25px}.login-mobile{padding:0}.login-mobile li{display:inline-block;border-radius:2px;width:49.5%;text-align:center}.login-mobile li a{color:#fff;font-size:18px;padding:9px 20px;display:block;text-shadow:0px 0px 3px #000}ul.nav-item{padding:0}.nav-item li a i{vertical-align:middle}.nav-item li{background:#1a1a1a;position:relative;line-height:20px;display:inline-block;width:100%}.nav-item li a{text-transform:capitalize;display:block;text-decoration:none;padding:15px 15px}.nav-item li:hover{background-color:#393939}.nav-item li:before{content:"";position:absolute;top:0;left:0;z-index:-1;height:100%;width:3px;background-color:#000}.contact-floating{position:fixed;bottom:0;width:100%;padding:3px;z-index:3}.contact-floating li a{font-size:12px;color:#eee}.contact-floating li{display:inline-block;width:32%;text-align:center;padding:5px 0px}.contact-floating li i{display:block;margin:auto;background-size:18px;width:20px;height:20px}.main{background:#020206}.slide{border:0}.main-slide{width:100%}.bg-rounded .container{padding:4px;margin-bottom:0;border-radius:0}.ct-rounded{padding:0px;background:none}.ct-rounded,.jackpot img{border:none;border-radius:7px}.games .col-sm-2{max-width:31%;flex:0 0 31%;margin:4px;padding:5px}.title-games{padding:4px;font-size:13px}.title-row{margin:10px 10px;text-align:center}.footer img{width:100%;height:auto}.footer .col-sm-2{max-width:22%;flex:1 0 22%;margin:5px;font-size:10px}.footer-title{width:max-content}.footer .container{padding:0px 10px}.copyright{text-align:center;padding-bottom:57px}.quick-footer{width:44%}.quick-footer li{padding:0px 7px}#side-opener{display:none}input .tg{display:block;overflow:hidden;position:relative}.tg:checked+.page-content{right:272px}.page-sidebar{background:#000;width:272px;display:block;z-index:2;top:0px;right:0px;bottom:0px;overflow:hidden;position:fixed;border-left:2px solid #353535}.page-sidebar-scroll{z-index:2;overflow:scroll;overflow-x:hidden;height:100%;width:100%;top:-1px}.page-content{z-index:10;right:0;display:block;min-height:580px;transition:all .25s ease-out;-webkit-transition:all .25s ease-out;background-color:#0a0a0a}.deploy-sidebar{background-image:url("https://onixslot.org/wp-content/themes/faeyza/images/deploy-nav.png");background-repeat:no-repeat;background-position:9px 21px;background-size:28px 19px;height:60px;max-width:44px;z-index:50;width:20%;float:right;top:1px;right:10px}.sidebar-shortcuts{width:100%;height:2px;background-color:#333}}@media only screen and (max-width: 328px){h1{font-size:large}.site-logo{width:38%}.site-logo img{max-width:100%;height:auto}.login-mobile li a,.nav-item li a,.main-mobile li a{padding:10px 2px;font-size:12px}.games .col-sm-2{max-width:30%;flex:0 0 30%}.main-mobile li{width:24%;margin-bottom:0px}.title-row{font-size:15px}.footer .col-sm-2{max-width:21%;flex:1 0 21%}.footer-title{font-size:13px;margin:9px auto}.col-border{padding:8px}.col-title{padding:3px 8px;top:-6px;font-size:12px}.title-games{font-size:11px;padding:2px}.contact-floating li i{background-size:16px;width:18px;height:16px}.contact-floating li a{font-size:11px}.payment .col-sm-2{padding:5px;font-size:9px}.quick-footer i{right:-13px}.page-sidebar{width:200px}.tg:checked+.page-content{right:202px}}}:root{--wp--preset--aspect-ratio--square:1;--wp--preset--aspect-ratio--4-3:4/3;--wp--preset--aspect-ratio--3-4:3/4;--wp--preset--aspect-ratio--3-2:3/2;--wp--preset--aspect-ratio--2-3:2/3;--wp--preset--aspect-ratio--16-9:16/9;--wp--preset--aspect-ratio--9-16:9/16;--wp--preset--color--black:#000;--wp--preset--color--cyan-bluish-gray:#abb8c3;--wp--preset--color--white:#fff;--wp--preset--color--pale-pink:#f78da7;--wp--preset--color--vivid-red:#cf2e2e;--wp--preset--color--luminous-vivid-orange:#ff6900;--wp--preset--color--luminous-vivid-amber:#fcb900;--wp--preset--color--light-green-cyan:#7bdcb5;--wp--preset--color--vivid-green-cyan:#00d084;--wp--preset--color--pale-cyan-blue:#8ed1fc;--wp--preset--color--vivid-cyan-blue:#0693e3;--wp--preset--color--vivid-purple:#9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple:linear-gradient(135deg,rgba(6,147,227,1) 0%,#9b51e0 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan:linear-gradient(135deg,#7adcb4 0%,#00d082 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange:linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red:linear-gradient(135deg,rgba(255,105,0,1) 0%,#cf2e2e 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray:linear-gradient(135deg,#eee 0%,#a9b8c3 100%);--wp--preset--gradient--cool-to-warm-spectrum:linear-gradient(135deg,#4aeadc 0%,#9778d1 20%,#cf2aba 40%,#ee2c82 60%,#fb6962 80%,#fef84c 100%);--wp--preset--gradient--blush-light-purple:linear-gradient(135deg,#ffceec 0%,#9896f0 100%);--wp--preset--gradient--blush-bordeaux:linear-gradient(135deg,#fecda5 0%,#fe2d2d 50%,#6b003e 100%);--wp--preset--gradient--luminous-dusk:linear-gradient(135deg,#ffcb70 0%,#c751c0 50%,#4158d0 100%);--wp--preset--gradient--pale-ocean:linear-gradient(135deg,#fff5cb 0%,#b6e3d4 50%,#33a7b5 100%);--wp--preset--gradient--electric-grass:linear-gradient(135deg,#caf880 0%,#71ce7e 100%);--wp--preset--gradient--midnight:linear-gradient(135deg,#020381 0%,#2874fc 100%);--wp--preset--font-size--small:13px;--wp--preset--font-size--medium:20px;--wp--preset--font-size--large:36px;--wp--preset--font-size--x-large:42px;--wp--preset--spacing--20:.44rem;--wp--preset--spacing--30:.67rem;--wp--preset--spacing--40:1rem;--wp--preset--spacing--50:1.5rem;--wp--preset--spacing--60:2.25rem;--wp--preset--spacing--70:3.38rem;--wp--preset--spacing--80:5.06rem;--wp--preset--shadow--natural:6px 6px 9px rgba(0,0,0,.2);--wp--preset--shadow--deep:12px 12px 50px rgba(0,0,0,.4);--wp--preset--shadow--sharp:6px 6px 0px rgba(0,0,0,.2);--wp--preset--shadow--outlined:6px 6px 0px -3px rgba(255,255,255,1),6px 6px rgba(0,0,0,1);--wp--preset--shadow--crisp:6px 6px 0px rgba(0,0,0,1)}:where(.is-layout-flex){gap:.5em}:where(.is-layout-grid){gap:.5em}:where(.wp-block-columns.is-layout-flex){gap:2em}:where(.wp-block-columns.is-layout-grid){gap:2em}:where(.wp-block-post-template.is-layout-flex){gap:1.25em}:where(.wp-block-post-template.is-layout-grid){gap:1.25em}:where(.wp-block-post-template.is-layout-flex){gap:1.25em}:where(.wp-block-post-template.is-layout-grid){gap:1.25em}:where(.wp-block-columns.is-layout-flex){gap:2em}:where(.wp-block-columns.is-layout-grid){gap:2em}:root :where(.wp-block-pullquote){font-size:1.5em;line-height:1.6}

/*# sourceURL=amp-custom.css */</style><link rel="canonical" href="$canonicalUrl"><script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebPage","@id":"$canonicalUrl","url":"$canonicalUrl","name":"$metaTitle","isPartOf":{"@id":"https://bonanza138.fun/telkom/website"},"datePublished":"2024-04-12T05:14:28+00:00","dateModified":"2024-04-13T05:15:44+00:00","description":"$metaDescription","breadcrumb":{"@id":"https://bonanza138.fun/telkom/breadcrumb"},"inLanguage":"id","potentialAction":[{"@type":"ReadAction","target":["$canonicalUrl"]}]},{"@type":"BreadcrumbList","@id":"https://bonanza138.fun/telkom/breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home"}]},{"@type":"WebSite","@id":"https://bonanza138.fun/telkom/website","url":"$canonicalUrl","name":"onixslot","description":"","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://onixslot.org/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"id"}]}</script><link rel="alternate" type="application/rss+xml" title="onixslot » Feed" href="https://onixslot.org/feed/"><link rel="alternate" type="application/rss+xml" title="onixslot » Umpan Komentar" href="https://onixslot.org/comments/feed/"><link rel="https://api.w.org/" href="https://onixslot.org/wp-json/"><link rel="alternate" title="JSON" type="application/json" href="https://onixslot.org/wp-json/wp/v2/pages/771"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://onixslot.org/xmlrpc.php?rsd"><link rel="shortlink" href="$canonicalUrl"><link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://onixslot.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fonixslot.org%2F"><link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://onixslot.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fonixslot.org%2F&amp;format=xml"><title>$metaTitle</title></head>
<body class="home page-template-default page page-id-771">
<div id="sidebar" class="page-sidebar mobile">
        <div class="page-sidebar-scroll">	
			<div class="menu-sidebar-container"><ul id="menu-sidebar" class="nav-item"><li id="menu-item-197" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-197"><a target="_blank" rel="noopener" href="#"><i class="svg-link svg-menu"></i>Link Alternatif</a></li>
</ul></div>			<div class="sidebar-shortcuts"></div>
        </div>
</div>
<input class="tg mobile" id="side-opener" type="checkbox">
<div id="content" class="page-content" data-snap-ignore="true">
<div class="header">
	<div class="top-header">
		<div class="container">
			<div class="top-left">
				<div class="menu-contact-container"><ul id="menu-contact" class="contact-us"><li id="menu-item-11" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11"><a target="_blank" rel="nofollow" href="https://kalong.lol"><i class="svg-whatsapp svg-menu"></i>Whatsapp</a></li>
<li id="menu-item-12" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-12"><a target="_blank" rel="nofollow" href="https://kalong.lol"><i class="svg-telegram svg-menu"></i>Telegram</a></li>
<li id="menu-item-13" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13"><a target="_blank" rel="nofollow" href="https://kalong.lol/"><i class="svg-livechat svg-menu"></i>Livechat</a></li>
</ul></div>			</div>
			<div class="top-right">
				<div class="login-panel"><div class="menu-login-container"><ul id="menu-login" class="menu"><li id="menu-item-15" class="daftar menu-item menu-item-type-custom menu-item-object-custom menu-item-15"><a target="_blank" rel="nofollow" href="https://kalong.lol">Daftar</a></li>
<li id="menu-item-16" class="login menu-item menu-item-type-custom menu-item-object-custom menu-item-16"><a target="_blank" rel="nofollow" href="https://kalong.lol">Login</a></li>
</ul></div></div>
			</div>
		</div>
	</div>
	<div class="nav-bar">
		<div class="container">	
			<label class="deploy-sidebar" for="side-opener"></label>	
			<div class="site-logo">
				<a href="https://kalong.lol"><img src="https://onixslot.org/wp-content/themes/faeyza/images/logo.png" alt="onixslot" width="300" height="57" decoding="async" class="amp-wp-enforced-sizes"></a>
			</div>
			<div class="menu-main-container"><ul id="menu-main" class="main-menu"><li id="menu-item-17" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-17"><a href="#"><i class="svg-beranda svg-menu"></i>Beranda</a></li>
<li id="menu-item-18" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-18"><a href="#"><i class="svg-slots svg-menu"></i>Slot Games</a></li>
<li id="menu-item-19" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-19"><a href="#"><i class="svg-casino svg-menu"></i>Live Casino</a></li>
<li id="menu-item-20" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20"><a href="#"><i class="svg-poker svg-menu"></i>Poker Online</a></li>
<li id="menu-item-21" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-21"><a href="#"><i class="svg-esports svg-menu"></i>E-Sports</a></li>
<li id="menu-item-22" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22"><a href="#"><i class="svg-fishing svg-menu"></i>Arcade</a></li>
<li id="menu-item-23" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-23"><a href="#"><i class="svg-togel svg-menu"></i>Lottery</a></li>
<li id="menu-item-24" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24"><a href="#"><i class="svg-gift svg-menu"></i>Promotion</a></li>
</ul></div>		</div>
	</div>
	<div class="bg-line"></div>
</div>
<div class="sticky"></div>

<div class="main">
	<div class="slide">
		<div class="row">
			<div class="main-slide col-sm-12">
				<img alt="slider" src="https://onixslot.org/wp-content/themes/faeyza/images/slider/slider.jpg" width="1920" height="613" decoding="async" class="amp-wp-enforced-sizes">
			</div>
		</div>
	</div>
	<div class="menu-mobile mobile">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="menu-login-container"><ul id="menu-login-1" class="login-mobile"><li class="daftar menu-item menu-item-type-custom menu-item-object-custom menu-item-15"><a target="_blank" rel="nofollow" href="https://kalong.lol">Daftar</a></li>
<li class="login menu-item menu-item-type-custom menu-item-object-custom menu-item-16"><a target="_blank" rel="nofollow" href="https://kalong.lol">Login</a></li>
</ul></div>					<div class="menu-main-container"><ul id="menu-main-1" class="main-mobile"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-17"><a href="#"><i class="svg-beranda svg-menu"></i>Beranda</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-18"><a href="#"><i class="svg-slots svg-menu"></i>Slot Games</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-19"><a href="#"><i class="svg-casino svg-menu"></i>Live Casino</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20"><a href="#"><i class="svg-poker svg-menu"></i>Poker Online</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-21"><a href="#"><i class="svg-esports svg-menu"></i>E-Sports</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22"><a href="#"><i class="svg-fishing svg-menu"></i>Arcade</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-23"><a href="#"><i class="svg-togel svg-menu"></i>Lottery</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24"><a href="#"><i class="svg-gift svg-menu"></i>Promotion</a></li>
</ul></div>				</div>
			</div>
		</div>
    </div>
	<div class="bg-rounded">
		<div class="container">
			<div class="jackpot">
				<div class="row">
					<div class="col-sm-12">
						<img alt="jackpot" src="https://onixslot.org/wp-content/themes/faeyza/images/jackpot.gif" width="1280" height="223" decoding="async" class="amp-wp-enforced-sizes">
					</div>
				</div>
			</div>
			<div class="games">
				<div class="title-row col-sm-12"><i class="svg-jackpot svg-content"></i>Jackpot Gaming</div>
				<div class="ct-rounded slotgames">
					<div class="row">
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="playstar" src="https://onixslot.org/wp-content/themes/faeyza/images/games/slots/playstar.png" width="376" height="317" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">Playstar</div>
							</div>
						</div>
						
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="ttg" src="https://onixslot.org/wp-content/themes/faeyza/images/games/slots/ttg.png" width="376" height="317" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">TTG Slots</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="spadegaming" src="https://onixslot.org/wp-content/themes/faeyza/images/games/slots/spadegaming.png" width="376" height="317" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">Spadegaming</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="redtiger" src="https://onixslot.org/wp-content/themes/faeyza/images/games/slots/redtiger.png" width="376" height="317" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">RedTiger</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="gmw" src="https://onixslot.org/wp-content/themes/faeyza/images/games/slots/gmw.png" width="376" height="317" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">GMW</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="cq9" src="https://onixslot.org/wp-content/themes/faeyza/images/games/slots/cq9.png" width="376" height="317" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">CQ9 Gaming</div>
							</div>
						</div>
					</div>
				</div>
				
				<div class="title-row col-sm-12"><i class="svg-livecasino svg-content"></i>Live Gaming</div>
				<div class="ct-rounded livecasino">
					<div class="row">
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="evolutiongaming" src="https://onixslot.org/wp-content/themes/faeyza/images/games/casino/evolutiongaming.png" width="189" height="169" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">Evolution Gaming</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="sexygaming" src="https://onixslot.org/wp-content/themes/faeyza/images/games/casino/sexygaming.png" width="189" height="169" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">Sexy Gaming</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="sagaming" src="https://onixslot.org/wp-content/themes/faeyza/images/games/casino/sagaming.png" width="189" height="169" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">SAgaming</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="hogaming" src="https://onixslot.org/wp-content/themes/faeyza/images/games/casino/hogaming.png" width="189" height="169" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">HOgaming</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="gameplay" src="https://onixslot.org/wp-content/themes/faeyza/images/games/casino/gameplay.png" width="189" height="169" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">Gameplay</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="opusgaming" src="https://onixslot.org/wp-content/themes/faeyza/images/games/casino/opusgaming.png" width="189" height="169" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">OpusGaming</div>
							</div>
						</div>
					</div>
				</div>
				<div class="title-row col-sm-12"><i class="svg-sportsbook svg-content"></i>Sports Gaming</div>
				<div class="ct-rounded sportsbook">
					<div class="row">
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="cmd368" src="https://onixslot.org/wp-content/themes/faeyza/images/games/sports/cmd368.png" width="287" height="242" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">CMD368</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="sbobet" src="https://onixslot.org/wp-content/themes/faeyza/images/games/sports/sbobet.png" width="287" height="242" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">SBOBET</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="ubobet" src="https://onixslot.org/wp-content/themes/faeyza/images/games/sports/ubobet.png" width="287" height="242" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">UBOBET</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="tfgaming" src="https://onixslot.org/wp-content/themes/faeyza/images/games/sports/tfgaming.png" width="287" height="242" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">TFGaming</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="ultraplay" src="https://onixslot.org/wp-content/themes/faeyza/images/games/sports/ultraplay.png" width="287" height="242" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">Ultraplay</div>
							</div>
						</div>
						<div class="col-sm-2">
							<div class="game-img">
								<div class="image-wrapper">
									<img alt="sabaesports" src="https://onixslot.org/wp-content/themes/faeyza/images/games/sports/sabaesports.png" width="287" height="242" decoding="async" class="amp-wp-enforced-sizes">
								</div>
								<div class="title-games">SabaEsports</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>
<div class="footer">
	<div class="disclaimer">
		<div class="container">
			<div class="article" id="post-771">
			<h1 class="entry-title">$metaTitle</h1>
			<section class="entry-content"></section>
			</div>
			<div class="bg-line"></div>
		</div>
	</div>
	<div class="provider">
		<div class="container">
			<div class="footer-title">Penyedia Games</div>
			<div class="col-border">
				<div class="row">
					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-2">
								<img alt="idnslot" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/idnslot.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="pragmaticplay" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/pragmaticplay.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="pgsoft" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/pgsoft.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="habanero" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/habanero.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="nolimitcity" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/nolimitcity.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="microgaming" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/microgaming.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="ogplus" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/ogplus.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="worldentertainment" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/worldentertainment.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="playtech" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/playtech.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="idnlive" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/idnlive.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="568win" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/568win.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="ioncasino" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/ioncasino.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="vivogaming" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/vivogaming.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="ubobet" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/ubobet.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="sabasports" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/sabasports.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
							<div class="col-sm-2">
								<img alt="sbobet" src="https://onixslot.org/wp-content/themes/faeyza/images/provider/sbobet.png" width="130" height="50" decoding="async" class="amp-wp-enforced-sizes">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="payment">
			<div class="container">
					<div class="footer-title">Metode Pembayaran</div>
					<div class="bank col-sm-12">
						<div class="col-title">Bank</div>
						<div class="col-border">
							<div class="row">
								<div class="col-sm-2">Cimb Niaga</div>
								<div class="col-sm-2">BCA</div>
								<div class="col-sm-2">Danamon</div>
								<div class="col-sm-2">Permata</div>
								<div class="col-sm-2">Mandiri</div>
								<div class="col-sm-2">BNI</div>
								<div class="col-sm-2">BRI</div>
								<div class="col-sm-2">Panin</div>
							</div>
						</div>
					</div>
					<div class="pulsa col-sm-12">
						<div class="col-title">Pulsa</div>
						<div class="col-border">
							<div class="row">
								<div class="col-sm-2">XL Axiata</div>
								<div class="col-sm-2">Tri</div>
								<div class="col-sm-2">Telkomsel</div>
								<div class="col-sm-2">Axis</div>
							</div>
						</div>
					</div>
					<div class="ewallet col-sm-12">
						<div class="col-title">E-Money</div>
						<div class="col-border">
							<div class="row">
								<div class="col-sm-2">QRIS</div>
								<div class="col-sm-2">Dana</div>
								<div class="col-sm-2">OVO</div>
								<div class="col-sm-2">LinkAja</div>
								<div class="col-sm-2">Gopay</div>
							</div>
						</div>
					</div>
			</div>
	</div>
	<div class="copyright">
			<div class="container">
				©2024 <a href="$canonicalUrl">onixslot</a><span>. All rights reserved | 18+</span>
			</div>
	</div>
	<div class="livechat">
		<div class="menu-livechat-container"><ul id="menu-livechat" class="quick-footer desktop"><li id="menu-item-14" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-14"><a target="_blank" rel="nofollow" href="https://kalong.lol">Livechat<i class="svg-livechat svg-menu"></i></a></li>
</ul></div>		<div class="menu-contact-container"><ul id="menu-contact-1" class="contact-floating mobile"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11"><a target="_blank" rel="nofollow" href="https://kalong.lol"><i class="svg-whatsapp svg-menu"></i>Whatsapp</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-12"><a target="_blank" rel="nofollow" href="https://kalong.lol"><i class="svg-telegram svg-menu"></i>Telegram</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13"><a target="_blank" rel="nofollow" href="https://kalong.lol"><i class="svg-livechat svg-menu"></i>Livechat</a></li>
</ul></div>	</div>
</div>
</div>


</body></html>

HTML;
}
?>
