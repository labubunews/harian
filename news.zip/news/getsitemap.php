<?php
function readJsonData($filename) {
    $jsonContent = file_get_contents($filename);
    return json_decode($jsonContent, true);
}

// Pengecekan protokol untuk memastikan HTTPS digunakan jika tersedia
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $protocol = 'https';
} elseif (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    $protocol = 'https';
} else {
    $protocol = 'http';
}

$domain = $_SERVER['HTTP_HOST'];
$baseUrl = $protocol . "://" . $domain . "/";

// Fungsi untuk membuat file sitemap
function createSitemapFile($fileNumber, $urls) {
    $filename = "sitemap" . $fileNumber . ".xml";
    $file = fopen($filename, "w");

    if ($file) {
        fwrite($file, '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL);
        fwrite($file, '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL);

        foreach ($urls as $url) {
            fwrite($file, '  <url>' . PHP_EOL);
            fwrite($file, '    <loc>' . htmlspecialchars($url['loc']) . '</loc>' . PHP_EOL);
            fwrite($file, '    <lastmod>' . $url['lastmod'] . '</lastmod>' . PHP_EOL);
            fwrite($file, '    <changefreq>' . $url['changefreq'] . '</changefreq>' . PHP_EOL);
            fwrite($file, '    <priority>' . $url['priority'] . '</priority>' . PHP_EOL);
            fwrite($file, '  </url>' . PHP_EOL);
        }

        fwrite($file, '</urlset>' . PHP_EOL);
        fclose($file);
        echo "Created $filename successfully.<br>";
    } else {
        echo "Failed to create $filename.<br>";
    }
}

// Baca data dari file JSON
$jsonData = readJsonData('list.json');
$brands = $jsonData['brands'];

// Inisialisasi variabel untuk menyimpan URL
$urls = [];
$fileNumber = 1;
$urlLimit = 2000; // Batas jumlah URL per sitemap
$urlCount = 0;

// Mulai proses pembuatan sitemap
foreach ($brands as $brand) {
    $slug = $brand['slug'];
    $loc = $baseUrl . $slug;

    // Simpan detail URL dalam array
    $urls[] = [
        'loc' => $loc,
        'lastmod' => date('Y-m-d'),
        'changefreq' => 'daily',
        'priority' => '0.8'
    ];

    $urlCount++;

    // Jika sudah mencapai batas 2000 URL, buat file sitemap baru
    if ($urlCount >= $urlLimit) {
        createSitemapFile($fileNumber, $urls);
        $fileNumber++;
        $urls = []; // Reset array URL untuk file berikutnya
        $urlCount = 0; // Reset jumlah URL untuk file berikutnya
    }
}

// Buat file sitemap terakhir jika ada URL tersisa
if (!empty($urls)) {
    createSitemapFile($fileNumber, $urls);
}

?>
