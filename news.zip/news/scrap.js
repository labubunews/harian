const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');
const readline = require('readline');

// Fungsi untuk membaca file list.txt dan mengembalikan array keyword
const readKeywordsFromFile = (filePath) => {
  return fs.readFileSync(filePath, 'utf-8').split('\n').map(line => line.trim()).filter(Boolean);
};

// Function untuk scraping satu query
const scrapeQuery = async (searchQuery, fileContent) => {
  try {
    // Ganti dengan URL pencarian Google
    const googleSearchURL = `https://www.google.com/search?q=${encodeURIComponent(searchQuery)}`;

    const { data: htmlData } = await axios.get(googleSearchURL, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });

    const $ = cheerio.load(htmlData);

    // Ambil setiap hasil pencarian
    $('.tF2Cxc').each((i, elem) => {
      const title = $(elem).find('h3').text();
      const metaDescription = $(elem).find('.VwiC3b').text();

      if (title && metaDescription) {
        // Menggunakan format "mantap168-1", "mantap168-2", dst. dengan tanda -
        fileContent.brands.push({
          slug: `${searchQuery.replace(/\s+/g, '')}-${fileContent.brands.length + 1}`,
          meta_title: title,
          meta_description: metaDescription
        });
      }
    });
  } catch (error) {
    console.error(`Error scraping for query "${searchQuery}":`, error.message);
  }
};

(async () => {
  try {
    // Baca file list.txt untuk mendapatkan daftar keyword
    const keywords = readKeywordsFromFile('list.txt');

    // Tentukan nama file output
    const fileName = 'list.json';

    // Cek apakah file sudah ada, jika ya, baca konten yang ada
    let fileContent = { brands: [] };
    if (fs.existsSync(fileName)) {
      const data = fs.readFileSync(fileName, 'utf-8');
      if (data) {
        try {
          fileContent = JSON.parse(data);
        } catch (err) {
          console.error('File JSON tidak valid, membuat file baru...');
          fileContent = { brands: [] };
        }
      }
    }

    // Proses scraping setiap keyword
    for (let i = 0; i < keywords.length; i++) {
      const keyword = keywords[i];
      console.log(`Scraping keyword ${i + 1} of ${keywords.length}: "${keyword}"`);

      // Jalankan scraping untuk keyword saat ini
      await scrapeQuery(keyword, fileContent);

      // Simpan hasil ke file JSON tanpa menunggu semua selesai
      fs.writeFileSync(fileName, JSON.stringify(fileContent, null, 2));

      // Delay untuk menghindari rate limiting (contoh: 2 detik per request)
      await new Promise(resolve => setTimeout(resolve, 2000));
    }

    console.log(`Scraping completed. Results saved to ${fileName}`);
  } catch (error) {
    console.error('Error in main process:', error.message);
  }
})();
